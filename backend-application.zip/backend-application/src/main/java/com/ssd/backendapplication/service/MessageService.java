package com.ssd.backendapplication.service;

import com.ssd.backendapplication.model.Message;

public interface MessageService {
    Message createMessage(Message message);
}
