package com.ssd.backendapplication.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfigurations {

}
